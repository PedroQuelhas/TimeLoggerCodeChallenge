﻿namespace Timelogger.Model
{
    public enum RequestResultStatus
    {
        SUCCESS,
        CONFLICT,
        NOT_FOUND,
        BAD_REQUEST,
        ERROR
    }
}
